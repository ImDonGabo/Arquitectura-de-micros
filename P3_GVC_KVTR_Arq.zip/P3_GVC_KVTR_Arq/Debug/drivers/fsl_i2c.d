drivers/fsl_i2c.o drivers/fsl_i2c.d: ../drivers/fsl_i2c.c \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\source\mcux_config.h \
 ../drivers/fsl_i2c.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/fsl_device_registers.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/LPC55S69_cm33_core0.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_ADC.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/LPC55S69_cm33_core0_COMMON.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/core_cm33.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/cmsis_version.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/cmsis_compiler.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/cmsis_gcc.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/m-profile/armv8m_mpu.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/system_LPC55S69_cm33_core0.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/LPC55S69_cm33_core0_features.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_AHB_SECURE_CTRL.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_ANACTRL.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_CASPER.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_CRC.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_CTIMER.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_DBGMAILBOX.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_DMA.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH_CFPA.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH_CMPA.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH_KEY_STORE.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLEXCOMM.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_GINT.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_GPIO.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_HASHCRYPT.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_I2C.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_I2S.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_INPUTMUX.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_IOCON.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_MAILBOX.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_MRT.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_OSTIMER.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PINT.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PLU.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PMC.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_POWERQUAD.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PRINCE.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PUF.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_RNG.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_RTC.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SCT.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SDIF.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SPI.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SYSCON.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SYSCTL.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USART.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USB.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBFSH.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBHSD.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBHSH.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBPHY.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_UTICK.h \
 C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_WWDT.h \
 ../drivers/fsl_common.h ../drivers/fsl_common_arm.h \
 ../drivers/fsl_clock.h ../drivers/fsl_reset.h ../drivers/fsl_flexcomm.h
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\source\mcux_config.h:
../drivers/fsl_i2c.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/fsl_device_registers.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/LPC55S69_cm33_core0.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_ADC.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/LPC55S69_cm33_core0_COMMON.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/core_cm33.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/cmsis_version.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/cmsis_compiler.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/cmsis_gcc.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\CMSIS/m-profile/armv8m_mpu.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/system_LPC55S69_cm33_core0.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device/LPC55S69_cm33_core0_features.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_AHB_SECURE_CTRL.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_ANACTRL.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_CASPER.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_CRC.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_CTIMER.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_DBGMAILBOX.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_DMA.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH_CFPA.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH_CMPA.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLASH_KEY_STORE.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_FLEXCOMM.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_GINT.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_GPIO.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_HASHCRYPT.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_I2C.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_I2S.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_INPUTMUX.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_IOCON.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_MAILBOX.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_MRT.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_OSTIMER.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PINT.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PLU.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PMC.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_POWERQUAD.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PRINCE.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_PUF.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_RNG.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_RTC.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SCT.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SDIF.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SPI.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SYSCON.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_SYSCTL.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USART.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USB.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBFSH.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBHSD.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBHSH.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_USBPHY.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_UTICK.h:
C:\Users\gabit\OneDrive\Documentos\mcu\P3_GVC_KVTR_Arq\device\periph/PERI_WWDT.h:
../drivers/fsl_common.h:
../drivers/fsl_common_arm.h:
../drivers/fsl_clock.h:
../drivers/fsl_reset.h:
../drivers/fsl_flexcomm.h:
